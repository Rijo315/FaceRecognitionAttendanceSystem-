import cv2
import os
import pandas as pd
from datetime import datetime, date
import numpy as np
import csv

class FaceAttendanceSystem:
    def __init__(self):
        print(" Starting Face Recognition Attendance System...")
        self.create_folders()
        self.students_file = "students.csv"
        self.attendance_file = f"attendance_{date.today().strftime('%Y-%m-%d')}.csv"
        self.photos_folder = "student_photos"

        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.students = self.load_students()
        
        print(f" Loaded {len(self.students)} registered students")
    
    def create_folders(self):
        """Create necessary folders if they don't exist"""
        if not os.path.exists("student_photos"):
            os.makedirs("student_photos")
    
    def load_students(self):
        """Load student data from CSV file"""
        if os.path.exists(self.students_file):
            try:
                df = pd.read_csv(self.students_file)
                return df.to_dict('records')
            except:
                print(" Starting fresh - no previous student data")
                return []
        return []
    
    def save_students(self):
        """Save student data to CSV"""
        if self.students:
            df = pd.DataFrame(self.students)
            df.to_csv(self.students_file, index=False)
            print(" Student data saved")
    
    def save_photo(self, name, regno, face_image):
        """Save student's face photo"""
        photo_filename = f"{regno}_{name}.jpg"
        photo_path = os.path.join(self.photos_folder, photo_filename)
        cv2.imwrite(photo_path, face_image)
        return photo_filename
    
    def register_student(self):
        """Register a new student"""
        print("\n" + "="*50)
        print("📝 REGISTER NEW STUDENT")
        print("="*50)
        
        name = input("Enter student name: ").strip()
        if not name:
            print(" Name cannot be empty!")
            return
        
        regno = input("Enter registration number: ").strip()
        if not regno:
            print(" Registration number cannot be empty!")
            return
        
        # Check if regno already exists
        for student in self.students:
            if student['regno'] == regno:
                print(f" Registration number {regno} already exists for {student['name']}!")
                return
        
        print(f"\n Ready to capture photo for {name} ({regno})")
        print("Instructions:")
        print("1. Look directly at the camera")
        print("2. Make sure your face is clearly visible")
        print("3. Press 'S' key to capture photo")
        print("4. Press 'ESC' key to cancel")
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print(" Error: Cannot open camera!")
            return
        
        photo_taken = False
        captured_face = None
        
        while True:
            ret, frame = cap.read()
            if not ret:
                print(" Failed to capture frame")
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
           
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(100, 100)
            )
            
            
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, "FACE DETECTED", (x, y-10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                
                
                captured_face = frame[y:y+h, x:x+w].copy()
            
           
            cv2.putText(frame, "Press 'S' to CAPTURE", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(frame, "Press 'ESC' to CANCEL", (10, 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(frame, f"Student: {name} ({regno})", (10, 90),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
            cv2.putText(frame, f"Faces detected: {len(faces)}", (10, 120),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, 
                       (0, 255, 0) if len(faces) == 1 else (0, 0, 255), 2)
            
            cv2.imshow('Register Student - Press S to Save', frame)
            
            key = cv2.waitKey(1) & 0xFF
            
            if key == ord('s') or key == ord('S'):  
                if len(faces) == 1 and captured_face is not None:
                    
                    photo_filename = self.save_photo(name, regno, captured_face)
                    
                    
                    self.students.append({
                        'name': name,
                        'regno': regno,
                        'photo': photo_filename,
                        'registered_date': date.today().strftime('%Y-%m-%d')
                    })
                    
                    
                    self.save_students()
                    
                    print(f"\n SUCCESS: {name} ({regno}) registered!")
                    print(f"📸 Photo saved as: {photo_filename}")
                    photo_taken = True
                    break
                else:
                    print(f"❌ Need exactly 1 face. Detected: {len(faces)} faces")
            
            elif key == 27:  
                print("❌ Registration cancelled")
                break
        
        cap.release()
        cv2.destroyAllWindows()
        
        if not photo_taken:
            print(" Registration incomplete - no photo taken")
    
    def take_attendance(self):
        """Take attendance using face recognition"""
        print("\n" + "="*50)
        print(" TAKE ATTENDANCE")
        print("="*50)
        
        if len(self.students) == 0:
            print(" No students registered yet!")
            print("Please register students first (Option 1)")
            return
        print(f" {len(self.students)} students in database")
        print("Looking for faces... (Press 'Q' to stop)")
        attendance_today = self.load_today_attendance()
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print(" Error: Cannot open camera!")
            return
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(100, 100)
            )
            for (x, y, w, h) in faces:
                face_roi = gray[y:y+h, x:x+w]
                matched_student = None              
                for student in self.students:
                    try:                     
                        photo_path = os.path.join(self.photos_folder, student['photo'])
                        if os.path.exists(photo_path):
                            student_photo = cv2.imread(photo_path, cv2.IMREAD_GRAYSCALE)
                            if student_photo is not None:
                                student_face = cv2.resize(student_photo, (w, h))
                                diff = np.sum(np.abs(face_roi.astype(float) - student_face.astype(float)))
                                if diff < (w * h * 30):  
                                    matched_student = student
                                    break
                    except:
                        continue
                if matched_student:
                    regno = matched_student['regno']
                    if regno in attendance_today:
                        color = (0, 0, 255)  
                        status = "Already Marked"
                    else:
                        current_time = datetime.now().strftime("%H:%M:%S")
                        attendance_today[regno] = current_time
                        self.mark_attendance(matched_student['name'], regno, current_time)
                        color = (0, 255, 0)  
                        status = f"Present at {current_time}"
                        print(f" {matched_student['name']} ({regno}) - Marked present")
                else:
                    color = (255, 255, 0)  
                    status = "Not Registered"
                    student_name = "Unknown"
                cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                cv2.rectangle(frame, (x, y-35), (x+w, y), color, cv2.FILLED)
                if matched_student:
                    cv2.putText(frame, matched_student['name'], (x+5, y-20),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
                cv2.putText(frame, status, (x+5, y-5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(frame, "Press 'Q' to Quit", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(frame, f"Students: {len(self.students)} | Marked: {len(attendance_today)}",
                       (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.imshow('Taking Attendance - Press Q to Stop', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cap.release()
        cv2.destroyAllWindows()
        print("\n Attendance session completed")
    def load_today_attendance(self):
        """Load today's attendance records"""
        attendance = {}
        if os.path.exists(self.attendance_file):
            try:
                df = pd.read_csv(self.attendance_file)
                for _, row in df.iterrows():
                    attendance[row['regno']] = row['time']
            except:
                pass
        return attendance
    def mark_attendance(self, name, regno, time):
        """Mark a student as present"""
        attendance_data = {
            'name': [name],
            'regno': [regno],
            'time': [time],
            'date': [date.today().strftime('%Y-%m-%d')]
        }
        df = pd.DataFrame(attendance_data)
        if os.path.exists(self.attendance_file):
            df.to_csv(self.attendance_file, mode='a', header=False, index=False)
        else:
            df.to_csv(self.attendance_file, index=False)
    def view_attendance(self):
        """View today's attendance"""
        print("\n" + "="*60)
        print(" TODAY'S ATTENDANCE RECORDS")
        print("="*60)
        if os.path.exists(self.attendance_file):
            df = pd.read_csv(self.attendance_file)
            if not df.empty:
                print("\n" + df.to_string(index=False))
                print("\n" + "-"*60)
                print(f" Total Present Today: {len(df)} students")
            else:
                print(" No attendance records for today")
        else:
            print(" No attendance file found for today")
        print("="*60)
    def view_students(self):
        """View all registered students"""
        print("\n" + "="*50)
        print(" REGISTERED STUDENTS")
        print("="*50)
        if not self.students:
            print(" No students registered yet")
        else:
            print(f"\nTotal Registered: {len(self.students)} students\n")
            print("-"*50)
            for i, student in enumerate(self.students, 1):
                print(f"{i:3}. {student['name']:20} - {student['regno']}")
                print(f"      Photo: {student['photo']}")
                print(f"      Registered: {student['registered_date']}")
                print()
            print("="*50)
    def view_student_photos(self):
        """View student photos"""
        print("\n" + "="*50)
        print(" STUDENT PHOTOS")
        print("="*50)
        if not os.path.exists(self.photos_folder):
            print(" No photos folder found")
            return
        photos = os.listdir(self.photos_folder)
        if not photos:
            print(" No student photos found")
            return
        print(f"\nFound {len(photos)} student photos:\n")
        for i, photo in enumerate(photos, 1):
            print(f"{i:3}. {photo}")
        choice = input("\nEnter photo number to view (or Enter to skip): ").strip()
        if choice and choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(photos):
                photo_path = os.path.join(self.photos_folder, photos[idx])
                img = cv2.imread(photo_path)
                if img is not None:
                    cv2.imshow(f"Student Photo: {photos[idx]}", img)
                    print("Press any key to close the photo...")
                    cv2.waitKey(0)
                    cv2.destroyAllWindows()
    def delete_all_data(self):
        """Delete all data (reset system)"""
        print("\n" + "="*50)
        print("  DELETE ALL DATA")
        print("="*50)
        confirm = input("Are you sure? This will delete ALL student data and photos. (yes/no): ").lower()
        if confirm == 'yes':
            if os.path.exists(self.students_file):
                os.remove(self.students_file)
                print(" Deleted students.csv")
            if os.path.exists(self.attendance_file):
                os.remove(self.attendance_file)
                print("Deleted attendance file")
            if os.path.exists(self.photos_folder):
                import shutil
                shutil.rmtree(self.photos_folder)
                print(" Deleted student photos folder")
            self.students = []
            print("\n All data deleted successfully!")
            print("System has been reset")
        else:
            print("Operation cancelled")
    def run(self):
        """Main menu"""
        while True:
            print("\n" + "="*60)
            print("🎯 FACE RECOGNITION ATTENDANCE SYSTEM")
            print("="*60)
            print("1. 📝 Register New Student")
            print("2. 📸 Take Attendance")
            print("3. 📊 View Today's Attendance")
            print("4. 👥 View All Registered Students")
            print("5. 🖼️ View Student Photos")
            print("6. 🗑️  Reset System (Delete All Data)")
            print("7. 🚪 Exit Program")
            print("="*60)
            choice = input("\n Enter your choice (1-7): ").strip()
            if choice == '1':
                self.register_student()
            elif choice == '2':
                self.take_attendance()
            elif choice == '3':
                self.view_attendance()
            elif choice == '4':
                self.view_students()
            elif choice == '5':
                self.view_student_photos()
            elif choice == '6':
                self.delete_all_data()
            elif choice == '7':
                print("\n Thank you for using the Attendance System!")
                print("Goodbye! ")
                break
            else:
                print(" Invalid choice! Please enter 1-7")
if __name__ == "__main__":
    try:
        system = FaceAttendanceSystem()
        system.run()
    except KeyboardInterrupt:
        print("\n\n Program interrupted by user")
    except Exception as e:
        print(f"\n Error: {e}")
        print("\nPlease check:")
        print("1. Make sure camera is connected")
        print("2. Install required packages: pip install opencv-python pandas numpy")
    finally:
        cv2.destroyAllWindows()